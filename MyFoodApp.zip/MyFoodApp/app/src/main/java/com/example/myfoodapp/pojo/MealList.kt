package com.example.myfoodapp.pojo

data class MealList(
    val meals: List<Meal>
)