package com.example.myfoodapp.pojo

data class MealsByCategoryList(
    val meals: List<MealsByCategory>
)