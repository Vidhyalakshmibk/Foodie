package com.example.myfoodapp.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.myfoodapp.databinding.CategoryMealItemBinding
import com.example.myfoodapp.pojo.Category
import com.example.myfoodapp.pojo.MealsByCategory

class CategoryMealAdapter :RecyclerView.Adapter<CategoryMealAdapter.CategoryMealsViewHolder>(){
    private var mealsList = ArrayList<MealsByCategory>()

    fun setMealsList(mealsList:List<MealsByCategory>){
        this.mealsList=mealsList as ArrayList<MealsByCategory>
        notifyDataSetChanged()
    }
inner class CategoryMealsViewHolder(val binding: CategoryMealItemBinding):RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): CategoryMealAdapter.CategoryMealsViewHolder {
       return CategoryMealsViewHolder(CategoryMealItemBinding.inflate(
           LayoutInflater.from(parent.context)
       ))
    }

    override fun onBindViewHolder(
        holder: CategoryMealAdapter.CategoryMealsViewHolder,
        position: Int
    ) {
       Glide.with(holder.itemView).load(mealsList[position].strMealThumb).into(holder.binding.imgMeal)
        holder.binding.tvMealName.text = mealsList[position].strMeal
    }

    override fun getItemCount(): Int {
        return mealsList.size
    }

}