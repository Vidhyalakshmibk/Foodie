package com.example.myfoodapp.pojo

data class CategoryList(
    val categories: List<Category>
)